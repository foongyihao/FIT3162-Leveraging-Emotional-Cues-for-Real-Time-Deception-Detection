import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Brain } from "lucide-react"
import Link from "next/link"

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8">
      <Card className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="inline-block rounded-lg bg-primary/10 p-2">
              <Brain className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-4xl font-bold tracking-tight">
              Micro-Expression Analysis Platform
            </h1>
            <p className="text-lg text-muted-foreground">
              Advanced AI-powered platform for detecting and analyzing facial micro-expressions
              in real-time. Perfect for research, security, and human behavior analysis.
            </p>
            <div className="flex gap-4">
              <Link href="/model">
                <Button size="lg">Access the Model</Button>
              </Link>
              <Link href="/dataset">
                <Button variant="outline" size="lg">Learn More</Button>
              </Link>
            </div>
          </div>
          <div className="relative aspect-video rounded-xl overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1499996860823-5214fcc65f8f?auto=format&fit=crop&q=80&w=1000"
              alt="AI Analysis Demo"
              className="object-cover w-full h-full"
            />
          </div>
        </div>
      </Card>
    </main>
  )
}