"use client"

import { useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Upload } from "lucide-react"
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

export default function ModelPage() {
  const [showError, setShowError] = useState(false)
  const [progress, setProgress] = useState(0)
  const [videoSrc, setVideoSrc] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const mockData = [
    { time: "0:02", expression: "Happiness", confidence: "95%" },
    { time: "0:05", expression: "Surprise", confidence: "87%" },
    { time: "0:08", expression: "Contempt", confidence: "92%" },
  ]

  const pieData = [
    { name: 'Happiness', value: 45 },
    { name: 'Surprise', value: 25 },
    { name: 'Contempt', value: 15 },
    { name: 'Neutral', value: 15 },
  ]

  const histogramData = [
    { time: '0:00', confidence: 85 },
    { time: '0:05', confidence: 92 },
    { time: '0:10', confidence: 78 },
    { time: '0:15', confidence: 95 },
    { time: '0:20', confidence: 88 },
    { time: '0:25', confidence: 90 },
  ]

  const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))']

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Check file type
    if (!file.type.startsWith('video/')) {
      setShowError(true)
      return
    }

    // Check file size (100MB = 100 * 1024 * 1024 bytes)
    if (file.size > 100 * 1024 * 1024) {
      setShowError(true)
      return
    }

    // Create object URL for video preview
    const videoUrl = URL.createObjectURL(file)
    setVideoSrc(videoUrl)

    // Simulate upload progress
    setProgress(0)
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 500)
  }

  const handleUploadClick = () => {
    fileInputRef.current?.click()
  }

  return (
    <main className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="p-6 space-y-6">
          <Select defaultValue="upload">
            <SelectTrigger>
              <SelectValue placeholder="Select input method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="upload">Upload Video</SelectItem>
              <SelectItem value="realtime">Real-Time Capture</SelectItem>
            </SelectContent>
          </Select>

          <div className="space-y-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              accept="video/*"
              className="hidden"
            />
            <Button
              onClick={handleUploadClick}
              className="w-full flex items-center justify-center gap-2"
            >
              <Upload className="h-4 w-4" />
              Upload Video
            </Button>
            <Progress value={progress} className="w-full" />
          </div>

          <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
            {videoSrc ? (
              <video
                src={videoSrc}
                controls
                className="absolute inset-0 w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-muted-foreground">Upload a video to preview</p>
              </div>
            )}
            <div className="absolute border-2 border-primary/50 w-1/3 h-1/3 left-1/3 top-1/3 pointer-events-none" />
          </div>
        </Card>

        <Card className="p-6 space-y-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Time</TableHead>
                <TableHead>Expression</TableHead>
                <TableHead>Confidence</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockData.map((row, i) => (
                <TableRow key={i}>
                  <TableCell>{row.time}</TableCell>
                  <TableCell>{row.expression}</TableCell>
                  <TableCell>{row.confidence}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="aspect-square bg-card rounded-lg flex items-center justify-center p-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius="80%"
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="aspect-video bg-card rounded-lg flex items-center justify-center p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={histogramData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="confidence" fill="hsl(var(--chart-1))" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <AlertDialog open={showError} onOpenChange={setShowError}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unsupported File</AlertDialogTitle>
            <AlertDialogDescription>
              The selected file is either too large or in an unsupported format.
              Please select a video file under 100MB in MP4 format.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  )
}